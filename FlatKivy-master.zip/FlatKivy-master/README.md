FlatKivy
========

A collection of experimental flat/material design widgets for Kivy.
